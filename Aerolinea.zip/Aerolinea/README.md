# Pagina-Web_Aerolinea
Esto software web, es una estructura de lo que pudiese ser una Aeroline.!
Lo que puede hacer con ella es registrar personal, registrar vuelos así como tambien mandarlos a una tabla para saber que vuelos estan disponibles.

Sera un software en constante desarollo, por lo tanto aun no esta terminador.!

Las tecnologias empleadas en el son.
°HTML 5
°CSS
°JavaScrip
°PHP

Templantes Utilizados.
°DIVI
°Boostrap

Espero te sirva, sea de tu agrado y tambien puedas disfrutarlo.
